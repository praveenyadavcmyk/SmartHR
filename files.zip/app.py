"""
app.py
------
This is the main entry point of our Flask application.

We use the "Application Factory" pattern here, meaning the Flask app is
created inside a function (create_app) instead of directly at the top
of the file. This is a Flask best practice because:
- It makes testing easier (you can create multiple app instances with
  different configs).
- It avoids circular imports as the project grows (e.g. when we add
  routes/blueprints for authentication and employees in later phases).

To run this app:
    python app.py
"""

from flask import Flask, jsonify
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
from flask_cors import CORS

from config import Config
from database import init_db

# -----------------------------------------------------------------
# Create extension objects here (not yet attached to an app).
# They get attached to the app inside create_app() using .init_app().
# This is the same pattern we used for `db` and `migrate` in database.py.
# -----------------------------------------------------------------
jwt = JWTManager()
bcrypt = Bcrypt()
cors = CORS()


def create_app():
    """
    Application factory function.

    Creates and configures the Flask app, then returns it.
    This is where all extensions (database, JWT, bcrypt, CORS) get
    connected to the app.

    Returns:
        Flask: A fully configured Flask application instance.
    """

    # Create the core Flask app object.
    app = Flask(__name__)

    # Load all configuration values (SECRET_KEY, database URI, etc.)
    # from the Config class defined in config.py.
    app.config.from_object(Config)

    # -----------------------------------------------------------------
    # Initialize extensions
    # -----------------------------------------------------------------

    # Connects SQLAlchemy (db) and Flask-Migrate (migrate) to this app.
    # See database.py for details.
    init_db(app)

    # Enables JWT-based authentication support.
    # We are not creating login routes yet (that's Phase 2), but we set
    # up the extension now so the app is ready for it.
    jwt.init_app(app)

    # Enables password hashing (used later when we create user accounts).
    bcrypt.init_app(app)

    # Enables Cross-Origin Resource Sharing, so a separate frontend
    # (e.g. React, Vue, or a mobile app) running on a different domain/port
    # can make requests to this API without being blocked by the browser.
    cors.init_app(app)

    # -----------------------------------------------------------------
    # Basic routes (temporary, just to verify the app works)
    # -----------------------------------------------------------------
    # In later phases, routes like these will move into their own
    # "blueprint" files (e.g. auth_routes.py, employee_routes.py).
    # For Phase 1, we just add a couple of simple routes to confirm
    # everything is wired up correctly.

    @app.route("/")
    def index():
        """A simple welcome route to confirm the server is running."""
        return jsonify({
            "message": "Welcome to the AI Smart Employee Management System API",
            "status": "running"
        })

    @app.route("/api/health")
    def health_check():
        """
        A health check route.

        This is commonly used to verify that the server (and its
        connections, like the database) are working correctly. Useful
        for monitoring tools or simply checking things manually in
        your browser or with a tool like Postman/curl.
        """
        return jsonify({
            "status": "healthy",
            "service": "smart-employee-management-api"
        }), 200

    return app


# -----------------------------------------------------------------
# Only run the development server if this file is executed directly
# (i.e. `python app.py`). This block will NOT run if app.py is
# imported somewhere else, e.g. by Flask-Migrate's `flask` CLI command.
# -----------------------------------------------------------------
if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
